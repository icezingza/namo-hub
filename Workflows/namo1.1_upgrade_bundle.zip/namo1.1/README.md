# namo1.1 — Character Evolution Hybrid

Quick Start and skeleton files included.
