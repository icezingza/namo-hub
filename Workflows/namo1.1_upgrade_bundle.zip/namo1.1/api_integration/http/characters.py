from fastapi import FastAPI
app = FastAPI(title='namo1.1')
