# Namo1.1 Full System

FastAPI + Core Modules.

## Run local
```
pip install -r requirements.txt
uvicorn api.main:app --reload
```

## Deploy Cloud Run
```
gcloud builds submit --tag gcr.io/PROJECT-ID/namo1.1
```
