from fastapi import FastAPI
from pydantic import BaseModel
from modules.memory_core import InfinityMemorySystem
from modules.emotion_engine import QuantumEmotionTagger
from modules.dharma_reasoning import DharmaReasoningModule
from modules.evolution_engine import InfinityEvolutionEngine
from modules.safety_system import SafetyAndCompliance

app = FastAPI(title="NaMo1.1 Flagship")

memory_system = InfinityMemorySystem()
emotion_engine = QuantumEmotionTagger()
dharma_module = DharmaReasoningModule()
evolution_engine = InfinityEvolutionEngine()
safety_system = SafetyAndCompliance()

class Request(BaseModel):
    query: str
    user_id: str = "anonymous"

@app.post("/process")
def process(request: Request):
    mem = memory_system.create_memory(request.query, {"user": request.user_id})
    mem_detail = memory_system.memory_db[mem["memory_id"]]
    analyzed = emotion_engine.analyze_emotions(mem_detail)
    reflection = dharma_module.generate_reflection(analyzed, [])
    safety = safety_system.check_compliance(content=request.query, context={"user": request.user_id})

    return {
        "memory_id": mem["memory_id"],
        "emotional_profile": mem["emotional_profile"],
        "reflection": reflection,
        "safety": safety
    }

@app.get("/")
def root():
    return {"message": "NaMo1.1 Flagship API is running 🚀"}
