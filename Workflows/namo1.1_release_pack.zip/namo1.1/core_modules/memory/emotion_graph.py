
class EmotionGraph:
    def __init__(self, backend=None):
        self.backend = backend or "sqlite:///emotion_graph.db"

    def upsert(self, character_id, mem_id, emo):
        return True
