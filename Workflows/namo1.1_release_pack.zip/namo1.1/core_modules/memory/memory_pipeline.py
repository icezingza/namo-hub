
from .vector_store import VectorStore
from .emotion_graph import EmotionGraph
from .consistency_analysis import analyze
from .breakthrough import make_breakthrough

class MemoryPipelineV11:
    def __init__(self, vs=None, eg=None):
        self.vs = vs or VectorStore()
        self.eg = eg or EmotionGraph()

    def ingest(self, character_id, event, emo):
        mem_id = self.vs.store(character_id, event, emo)
        self.eg.upsert(character_id, mem_id, emo)
        linked = self.vs.find_linked(character_id, mem_id)
        report = analyze(mem_id, linked, emo)
        insight = make_breakthrough(mem_id, linked, report, self.eg, self.vs)
        return mem_id, insight
