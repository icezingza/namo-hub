
class VectorStore:
    def __init__(self, url=None, collection=None):
        self.url = url or "chroma://localhost:8000"
        self.collection = collection or "character_memories"

    def store(self, character_id, event, emo):
        return f"mem_{character_id}_{abs(hash(event['summary']))%100000}"

    def find_linked(self, character_id, mem_id):
        return []
