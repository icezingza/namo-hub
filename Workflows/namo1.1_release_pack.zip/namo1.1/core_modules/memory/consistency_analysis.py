
def analyze(mem_id, linked, emo):
    class Report:
        def __init__(self):
            self.conflict = False
            self.summary = "ok"
    return Report()
