
class Insight:
    def __init__(self, text, themes, conflict_resolved):
        self.text = text
        self.themes = themes
        self.conflict_resolved = conflict_resolved

def make_breakthrough(mem_id, linked, report, eg, vs):
    return Insight(
        text="Protection reframes betrayal into forgiveness.",
        themes=["forgiveness","compassion"],
        conflict_resolved=True
    )
