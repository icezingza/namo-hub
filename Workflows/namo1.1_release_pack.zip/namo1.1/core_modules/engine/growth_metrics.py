
from collections import defaultdict

class GrowthMetrics:
    def __init__(self):
        self._store = defaultdict(lambda: {"wisdom":0.5,"empathy":0.5,"resilience":0.5})

    def update(self, character_id, deltas):
        cur = self._store[character_id]
        for k,v in deltas.items():
            if k not in cur:
                cur[k] = 0.0
            cur[k] = max(0.0, min(1.0, cur[k] + v))

    def snapshot(self, character_id):
        return dict(self._store[character_id])
