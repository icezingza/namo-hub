
from collections import defaultdict

class PersonalityMatrix:
    def __init__(self):
        self._store = defaultdict(lambda: {"timid":0.2,"brave":0.3,"cynical":0.2,"hopeful":0.3})

    def shift(self, character_id, deltas):
        cur = self._store[character_id]
        for k,v in deltas.items():
            if k not in cur:
                cur[k] = 0.0
            cur[k] = max(0.0, min(1.0, cur[k] + v))

    def snapshot(self, character_id):
        return dict(self._store[character_id])
