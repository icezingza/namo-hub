
from .personality_matrix import PersonalityMatrix
from .growth_metrics import GrowthMetrics

class CharacterEvolutionEngine:
    def __init__(self):
        self.pm = PersonalityMatrix()
        self.gm = GrowthMetrics()

    def evolve(self, character_id, insight, emotion_summary):
        tags = set((emotion_summary or {}).get("tags", []))
        themes = set((getattr(insight, "themes", []) or []))

        deltas_trait = {
            "timid":   -0.05 if "protection" in tags else 0.0,
            "brave":    0.08 if "protection" in tags else 0.0,
            "hopeful":  0.10 if "forgiveness" in themes else 0.0,
            "cynical": -0.07 if "forgiveness" in themes else 0.0,
        }
        self.pm.shift(character_id, deltas_trait)

        deltas_growth = {
            "empathy":    0.06 if "compassion" in themes else 0.0,
            "wisdom":     0.05 if getattr(insight, "conflict_resolved", False) else 0.0,
            "resilience": 0.04 if "survived_danger" in tags else 0.0,
        }
        self.gm.update(character_id, deltas_growth)

        return self.pm.snapshot(character_id), self.gm.snapshot(character_id)
