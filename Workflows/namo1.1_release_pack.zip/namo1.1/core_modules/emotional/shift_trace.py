
_shift_log = {}

def update_trace(character_id, tag):
    _shift_log.setdefault(character_id, []).append(tag)
    return True
