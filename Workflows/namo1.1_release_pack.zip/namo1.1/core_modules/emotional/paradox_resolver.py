
def resolve_paradox(tag):
    # placeholder: return as-is
    return tag
