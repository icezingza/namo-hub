
def auto_tag(text):
    # rudimentary example: if 'shield' in text -> protection tag
    tags = []
    if 'shield' in text or 'shields' in text or 'protect' in text:
        tags.append('protection')
    if not tags:
        tags.append('neutral')
    return {'tags': tags, 'intensity': {t:0.8 for t in tags}}
