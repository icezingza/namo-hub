
from .auto_tag import auto_tag
from .paradox_resolver import resolve_paradox
from .shift_trace import update_trace
from .compassion_engine import craft_compassionate_reply

def process_emotion(character_id, text):
    tag = auto_tag(text)
    tag = resolve_paradox(tag)
    update_trace(character_id, tag)
    reply = craft_compassionate_reply(tag)
    return tag, reply
