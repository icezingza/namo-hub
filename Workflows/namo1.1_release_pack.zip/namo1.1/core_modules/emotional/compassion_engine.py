
def craft_compassionate_reply(tag):
    return "I will stand with you. You are safe with me."
