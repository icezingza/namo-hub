
# 🌌 NamoVerse Flagship — **namo1.1**
Character Evolution Hybrid (Engine + Memory + Emotional)

This package contains **working skeleton code** for the namo1.1 internal upgrade: characters that **remember**, **feel**, and **grow**.

## Quick Start
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt  # make sure to add: fastapi uvicorn

cp .env.example .env
uvicorn api_integration.http.characters:app --reload

# Send a demo event
curl -X POST http://localhost:8000/v1/characters/char_A/events   -H "Content-Type: application/json"   -d '{"summary":"Player shields me at the gate","timestamp":"2025-09-19T07:55:23.821063Z","related_to":["player:hero_01"]}'

# Inspect state
curl http://localhost:8000/v1/characters/char_A/state
```

## Contents
- `core_modules/engine/` – CharacterEvolutionEngine, PersonalityMatrix, GrowthMetrics
- `core_modules/memory/` – VectorStore (adapter), EmotionGraph (adapter), Consistency Analysis, Breakthrough generator, Pipeline
- `core_modules/emotional/` – auto_tag, paradox_resolver, compassion_engine, shift_trace, pipeline
- `api_integration/http/characters.py` – FastAPI endpoints
- `examples/scenes/scene_trust_arc.json` – demo scene
- `tests/` – test skeletons
- `.env.example` – required settings
