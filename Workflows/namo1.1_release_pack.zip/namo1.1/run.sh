#!/usr/bin/env bash
uvicorn api_integration.http.characters:app --reload
