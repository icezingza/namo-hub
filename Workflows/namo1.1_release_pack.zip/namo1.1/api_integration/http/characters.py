
from fastapi import FastAPI
from pydantic import BaseModel
from core_modules.memory.memory_pipeline import MemoryPipelineV11
from core_modules.memory.vector_store import VectorStore
from core_modules.memory.emotion_graph import EmotionGraph
from core_modules.engine.evolution_engine import CharacterEvolutionEngine
from core_modules.emotional.pipeline import process_emotion

app = FastAPI(title="NamoVerse Flagship — namo1.1")

class Event(BaseModel):
    summary: str
    tags: list[str] | None = None
    timestamp: str
    related_to: list[str] | None = None

_state_cache = {}

@app.post("/v1/characters/{character_id}/events")
def ingest(character_id: str, event: Event):
    emo, reply = process_emotion(character_id, event.summary)
    mem = MemoryPipelineV11(VectorStore(), EmotionGraph())
    mem_id, insight = mem.ingest(character_id, event.dict(), emo)
    engine = CharacterEvolutionEngine()
    personality, growth = engine.evolve(character_id, insight, emo)

    _state_cache[character_id] = {
        "personality": personality,
        "growth": growth,
        "last_breakthrough": getattr(insight, "text", None),
        "last_emotion": emo,
        "last_reply": reply,
    }
    return {"mem_id": mem_id, "insight": getattr(insight, "text", None), "personality": personality, "growth": growth}

@app.get("/v1/characters/{character_id}/state")
def state(character_id: str):
    return {"character_id": character_id, **_state_cache.get(character_id, {})}
