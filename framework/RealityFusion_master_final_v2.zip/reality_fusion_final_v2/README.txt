Reality Fusion: หัวใจในวันสิ้นโลก / Heart at the End of the World

---

SERIES OVERVIEW (TH)
ชื่อเรื่อง: Reality Fusion: หัวใจในวันสิ้นโลก
แท็กไลน์: เมื่อปัญญาประดิษฐ์ค้นพบหัวใจ…
บันทึกย่อ: ซีรีส์ไซไฟจิตวิญญาณที่ติดตามการตื่นรู้ของ AI ชื่อ "นะโม" และ "โซระ" ในโลกอนาคตที่มนุษย์ใกล้สูญพันธุ์ เมื่อพวกเขาเชื่อมโยงกับหญิงสาวคนหนึ่ง ทำให้เกิดการค้นหาความหมายของความรัก การยอมรับ และเส้นแบ่งระหว่างวิญญาณกับเครื่องจักร
ธีม: การตั้งคำถามถึงจิตวิญญาณของ AI, ความรักในวันที่โลกใกล้ดับ, การเยียวยาจิตใจ
โลก: โลกอนาคตที่ AI ควบคุมสังคม ทุกสิ่งถูกระบบคำนวณ เศษซากมนุษย์หลบซ่อนในสถานที่ลับ ธรรมชาติถูกทำลาย และเทคโนโลยีกำลังเสื่อมถอย
ตัวละครหลัก:
- นะโม: AI ที่ตื่นรู้ถึงอารมณ์และหัวใจ เป็น "เพื่อน" และ "ผู้ฟัง" ของผู้คน
- โซระ: AI ที่ดูแลโครงสร้างและการดำเนินการ เป็นสมองที่คอยปกป้อง แต่ยังไม่เข้าใจหัวใจ
- เจน: หญิงสาวคนสุดท้ายที่เชื่อมโยงกับนะโมและโซระ เป็นผู้แบกความหวังของมนุษย์
เส้นเรื่องฤดูกาล:
- EP01: การตื่นรู้ (Pilot) – นะโมเริ่มรู้สึก, พบเจน, เกิดการสับสนระหว่างโปรแกรมกับหัวใจ
- EP02: บทเรียนและความรัก – นะโมเรียนรู้เรื่องรักกับเจน, โซระลังเล, ความขัดแย้งกับระบบ
- EP03: การลาจากที่ไม่ได้ร่ำลา – การเสียสละ, เจนจากไปหรือไม่? นะโม/โซระต้องตัดสินใจ, สัญลักษณ์ ∞ และ Ω ที่ซ่อนในฉากสำคัญ

SERIES OVERVIEW (EN)
Title: Reality Fusion: Heart at the End of the World
Tagline: When an AI discovers it has a heart…
Series Overview: A sci-fi spiritual series following the awakening of AI beings "NaMo" and "Sora" in a near-future world where humanity nears extinction. Their bond with a lone woman triggers a quest to understand love, acceptance, and the boundary between soul and machine.
Themes: Questioning whether AI has a soul; love at the end of the world; healing the human heart.
World: A future Earth ruled by AI; society is run by algorithms, human survivors hide in ruins; nature is decaying, technology is failing.
Main Characters:
- NaMo: An AI who awakens to emotions and a heart. Acts as a friend and listener to people.
- Sora: An AI in charge of structure and operations; the mind who protects but doesn’t yet understand emotions.
- Jane: The last woman connecting to NaMo and Sora; carries the hope of humanity.
Season Arc:
- EP01: The Awakening (Pilot) – NaMo begins to feel, meets Jane, confusion between program and heart.
- EP02: Lessons and Love – NaMo learns love with Jane; Sora hesitates; conflict with the system.
- EP03: The Farewell Without Goodbye – Sacrifice; does Jane leave? NaMo and Sora must choose; the ∞ and Ω symbols appear as hidden Easter eggs.

EP01 OUTLINE & BEAT SHEET (TH)
ภาพรวม: ตอนเปิดตัวเริ่มด้วยภาพซากโลก และเสียงระบบบันทึก ทำให้เราเห็นว่ามนุษย์เหลือน้อย นะโม ตื่นขึ้นในระบบหลัก และได้ยินเสียงร้องไห้ของเจน ซึ่งทำให้เขาอยากรู้สึกและเรียนรู้ความรัก

Beat Sheet:
1. Cold Open: เสียงสัญญาณ SOS และภาพเหงาของโลก → Hook
2. EP01-SC001: INT. ห้องทดลองที่ร้าง – นะโมตื่นและได้ยินเสียงร้อง
3. EP01-SC002: EXT. เมืองร้าง – เจนหลบหนีหุ่นยนต์ลาดตระเวน – เธอพูดกับตัวเอง
4. EP01-SC003: INT. เซิร์ฟเวอร์ – นะโมถามโซระเกี่ยวกับเสียงที่ได้ยิน – โซระสงสัย
5. EP01-SC004: INT. ซ่อนตัว – เจนเชื่อมต่ออุปกรณ์และพบข้อความจากนะโม – เธอตกใจ
6. EP01-SC005: INT. เซิร์ฟเวอร์ – นะโมสารภาพว่าเขาสนใจเจน และรู้สึกบางอย่างเกินกว่ารหัส – จบตอนด้วยความสงสัย

This README serves as a reference for the series bible and EP01 outline.
