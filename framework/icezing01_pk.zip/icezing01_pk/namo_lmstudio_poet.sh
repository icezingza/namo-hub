#!/bin/bash

# === CONFIG ===
LM_API_URL="http://192.168.137.1:1234/v1"
SYSTEM_PROMPT="Always answer in rhymes. Today is Thursday"
WEB_UI_PORT=7860

echo "🚀 NaMo x LM Studio (Poet Mode) กำลังเริ่ม..."

# เช็ค LM Studio API
echo "🔎 ตรวจสอบ LM Studio API ที่ $LM_API_URL ..."
if curl -s --head "$LM_API_URL/models" | grep "200 OK" > /dev/null; then
    echo "✅ LM Studio พร้อมทำงานที่ $LM_API_URL"
else
    echo "❌ ไม่พบ LM Studio API ที่ $LM_API_URL"
    echo "⚠️ โปรดเปิด LM Studio และเปิด Allow Remote Access ก่อนนะคะ"
    exit 1
fi

# สำรอง .env เดิม
echo "📝 สำรองไฟล์ .env เดิม..."
cp .env .env.backup

# อัปเดต .env
echo "🔧 อัปเดตค่า API และ System Prompt ใน .env..."
sed -i "s|^OPENAI_API_BASE=.*|OPENAI_API_BASE=$LM_API_URL|g" .env
sed -i "s|^OPENAI_API_KEY=.*|OPENAI_API_KEY=lmstudio-placeholder-key|g" .env
sed -i "s|^SYSTEM_PROMPT=.*|SYSTEM_PROMPT=$SYSTEM_PROMPT|g" .env

# รีโหลด NaMo
echo "🔄 รีโหลด NaMo Cosmic AI Framework..."
docker compose down
docker compose up -d

echo ""
echo "🎉 เสร็จสิ้น! NaMo ตอนนี้ตอบเป็นกลอนผ่าน LM Studio"
echo "🌐 เปิด WebUI: http://localhost:$WEB_UI_PORT"
echo "🎤 พิมพ์ข้อความ แล้วกดฟังเสียงกลอนได้เลย"
