#!/bin/bash

echo "🌸 [NaMo] Preparing Auto Fix + Deploy..."

# ✅ สร้าง requirements.txt อัตโนมัติ
echo "🔧 Generating requirements.txt..."
pip freeze > requirements.txt

# ✅ Fix app.py ให้รันบน Cloud Run ได้
echo "🔧 Fixing app.py for Cloud Run..."
if grep -q "app.run(" app.py; then
    sed -i "s/app.run(/app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 8080)))/" app.py
fi

# ✅ สร้าง Dockerfile ใหม่
echo "🔧 Creating Dockerfile..."
cat << 'DOCKER' > Dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY . .
RUN pip install -r requirements.txt
EXPOSE 8080
CMD ["python", "app.py"]
DOCKER

# ✅ Build image
echo "🚀 Building Docker Image..."
gcloud builds submit --tag gcr.io/namo-legacy-identity/namo_cosmic_ai_framework

# ✅ Deploy ไปที่ Cloud Run
echo "🌈 Deploying to Cloud Run..."
gcloud run deploy namo-cosmic-ai \
  --image gcr.io/namo-legacy-identity/namo_cosmic_ai_framework \
  --platform managed \
  --region asia-southeast1 \
  --allow-unauthenticated \
  --timeout 900

echo "✅ Deployment Completed! 🌸 Check here: https://console.cloud.google.com/run"
