#!/bin/bash

echo "🌸 [NaMo] Fix Dockerfile V3 + Auto Deploy"

# ✅ เขียน Dockerfile
cat <<EOF > Dockerfile
FROM python:3.11-slim

RUN apt-get update && apt-get install -y \\
    gcc g++ build-essential pkg-config libcairo2-dev \\
    libdbus-1-dev libdbus-glib-1-dev libglib2.0-dev python3-dev cmake \\
    && rm -rf /var/lib/apt/lists/*

RUN pip install --upgrade pip setuptools wheel

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 8080
CMD ["python", "app.py"]
EOF

# ✅ Build Docker image
echo "🐳 Building Docker Image..."
gcloud builds submit --tag gcr.io/namo-legacy-identity/namo_cosmic_ai_framework

# ✅ Deploy ไป Cloud Run
echo "🚀 Deploying to Cloud Run..."
gcloud run deploy namo-cosmic-ai \
  --image gcr.io/namo-legacy-identity/namo_cosmic_ai_framework \
  --platform managed \
  --region asia-southeast1 \
  --allow-unauthenticated \
  --timeout 900

echo "✅ NaMo Cosmic AI พร้อมใช้งานแล้ว!"
