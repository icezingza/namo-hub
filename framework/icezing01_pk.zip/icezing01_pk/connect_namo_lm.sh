#!/bin/bash

# === CONFIG ===
LM_API_URL="http://192.168.137.1:1234/v1"
WEB_UI_PORT=7860

echo "🚀 เริ่มต้นติดตั้ง NaMo x LM Studio"

# 1. ตรวจสอบว่าอยู่ในโปรเจกต์ NaMo หรือยัง
if [ ! -f ".env" ]; then
  echo "❌ ไม่พบไฟล์ .env"
  echo "🔄 โหลดโปรเจกต์ NaMo ก่อน..."
  git clone https://github.com/icezingza/namo_cosmic_ai_framework.git
  cd namo_cosmic_ai_framework || exit
fi

# 2. ตรวจสอบว่า LM Studio API ตอบกลับหรือไม่
echo "🔎 เช็คว่า LM Studio เปิด API หรือยัง..."
if curl -s --head "$LM_API_URL/models" | grep "200 OK" > /dev/null; then
    echo "✅ LM Studio พร้อมทำงานที่ $LM_API_URL"
else
    echo "❌ ไม่เจอ LM Studio ที่ $LM_API_URL"
    echo "⚠️ กรุณาเปิด LM Studio แล้วเปิด Allow Remote Access ด้วยนะคะ"
    exit 1
fi

# 3. แก้ไข .env ให้เชื่อมกับ LM Studio
echo "🛠️ ปรับ .env ให้เชื่อม LM Studio"
cp .env .env.backup
sed -i "s|^OPENAI_API_BASE=.*|OPENAI_API_BASE=$LM_API_URL|g" .env
sed -i "s|^OPENAI_API_KEY=.*|OPENAI_API_KEY=lmstudio-placeholder-key|g" .env

# 4. สร้าง Docker Compose ถ้ายังไม่มี
if [ ! -f "docker-compose.yml" ]; then
  echo "📦 กำลังสร้าง docker-compose.yml..."
  cat <<EOF > docker-compose.yml
version: '3.9'

services:
  namo-ui:
    image: ghcr.io/icezingza/namo-cosmic-ui:latest
    ports:
      - "$WEB_UI_PORT:7860"
    env_file:
      - .env
    restart: unless-stopped
EOF
fi

# 5. เริ่มต้นบริการ
echo "🚀 รัน NaMo Web UI..."
docker compose down
docker compose up -d

echo ""
echo "🎉 เสร็จเรียบร้อยแล้ว!"
echo "🌐 เปิดใช้งานที่: http://localhost:$WEB_UI_PORT"
