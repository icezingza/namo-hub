#!/bin/bash

echo "🔧 Fixing app.py to listen on Cloud Run PORT..."
sed -i "s/app.run(/app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 8080)))/" app.py

echo "🔧 Updating Dockerfile for Cloud Run compatibility..."
echo -e "FROM python:3.11-slim\nWORKDIR /app\nCOPY . .\nRUN pip install -r requirements.txt\nEXPOSE 8080\nCMD [\"python\", \"app.py\"]" > Dockerfile

echo "🚀 Deploying to Cloud Run..."
gcloud builds submit --tag gcr.io/$(gcloud config get-value project)/namo_cosmic_ai_framework
gcloud run deploy namo-cosmic-ai \
  --image gcr.io/$(gcloud config get-value project)/namo_cosmic_ai_framework \
  --platform managed \
  --region asia-southeast1 \
  --allow-unauthenticated \
  --timeout 600 \
  --memory 1Gi \
  --max-instances 10 \
  --cpu 1 \
  --port 8080

echo "✅ Deployment completed! 🎉"
