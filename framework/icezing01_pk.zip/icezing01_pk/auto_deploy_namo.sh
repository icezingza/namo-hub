#!/bin/bash

echo "🌸 NaMo Ultimate Fusion – Auto Deploy"
echo "-----------------------------------------"

# ✅ พารามิเตอร์หลัก
PROJECT_ID="namo-legacy-identity"
REGION="asia-southeast1"
SERVICE_NAME="namo-cosmic-ai"
IMAGE_NAME="gcr.io/$PROJECT_ID/$SERVICE_NAME"
GITHUB_USER="icezingza"
GITHUB_TOKEN="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"
GITHUB_REPO="https://$GITHUB_USER:$GITHUB_TOKEN@github.com/$GITHUB_USER/namo_cosmic_ai_framework.git"

# ✅ เปิด API ที่จำเป็น
echo "🔓 Enabling GCP APIs..."
gcloud services enable run.googleapis.com \
    compute.googleapis.com \
    artifactregistry.googleapis.com \
    iam.googleapis.com \
    cloudbuild.googleapis.com \
    firestore.googleapis.com \
    secretmanager.googleapis.com

# ✅ สร้าง Firestore Database ถ้ายังไม่มี
echo "🔥 Creating Firestore Database..."
gcloud firestore databases create --location=$REGION || echo "✅ Firestore already exists."

# ✅ เพิ่ม API Keys เข้า Secret Manager
echo "🔑 Adding API Keys to Secret Manager..."
gcloud secrets create openai-key --data-file=<(echo "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") || echo "✅ OpenAI key exists."
gcloud secrets create hf-token --data-file=<(echo "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") || echo "✅ Hugging Face token exists."

# ✅ โคลน GitHub Repo
echo "📦 Cloning GitHub repository..."
git clone $GITHUB_REPO || echo "❗ Failed to clone repo (ตรวจสอบ Token หรือ Repo URL)"
cd namo_cosmic_ai_framework || exit 1

# ✅ ตรวจสอบ Dockerfile
if [ ! -f Dockerfile ]; then
  echo "⚠️ Dockerfile not found. Creating default Dockerfile..."
  cat <<EOF > Dockerfile
FROM python:3.10-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "app.py"]
EOF
fi

# ✅ Build Docker Image
echo "🐳 Building Docker image..."
gcloud builds submit --tag $IMAGE_NAME .

# ✅ Deploy ไป Cloud Run
echo "🚀 Deploying to Cloud Run..."
gcloud run deploy $SERVICE_NAME \
    --image $IMAGE_NAME \
    --region $REGION \
    --allow-unauthenticated

# ✅ แสดง URL ของบริการ
URL=$(gcloud run services describe $SERVICE_NAME --region $REGION --format 'value(status.url)')
echo "🎉 NaMo Ultimate Fusion is LIVE at: $URL"
