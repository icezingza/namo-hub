import requests
import os # นำเข้าโมดูล os สำหรับจัดการไฟล์และเส้นทาง

# Your Eleven Labs API key
# นี่คือคีย์ API ของคุณสำหรับ Eleven Labs
ELEVENLABS_API_KEY = "sk_88befb89fe36a0759036638b374984d99d2d2be1da3971a5"

# The specific Voice ID you want to preview
# นี่คือ Voice ID ของเสียงที่คุณต้องการดูตัวอย่าง (จาก Eleven Labs Voice Library)
VOICE_ID_TO_PREVIEW = "eVItLK1UvXctxuaRV2Oq"

# Construct the correct URL for the voice stream API endpoint
# สร้าง URL ที่ถูกต้องสำหรับ endpoint API การสตรีมเสียง
url = f"https://api.elevenlabs.io/v1/text-to-voice/{VOICE_ID_TO_PREVIEW}/stream"

# Set up the headers for the API request
# ตั้งค่า headers สำหรับ request API โดยใส่ API key ของคุณ
headers = {
  "xi-api-key": ELEVENLABS_API_KEY
}

print(f"กำลังพยายามสตรีมตัวอย่างเสียงสำหรับ Voice ID: {VOICE_ID_TO_PREVIEW}...")

try:
    # Send a GET request to the Eleven Labs API
    # Use stream=True to handle the audio stream efficiently
    # ส่งคำขอ GET ไปยัง Eleven Labs API
    # ใช้ stream=True เพื่อจัดการกับการสตรีมเสียงอย่างมีประสิทธิภาพ
    response = requests.get(url, headers=headers, stream=True)

    # Raise an HTTPError for bad responses (4xx or 5xx status codes)
    # ตรวจสอบสถานะการตอบกลับ หากมีข้อผิดพลาด (เช่น 404 Not Found, 401 Unauthorized) จะแจ้งข้อผิดพลาด
    response.raise_for_status()

    # Check the Content-Type header to ensure we received audio data
    # ตรวจสอบส่วนหัว Content-Type เพื่อให้แน่ใจว่าได้รับข้อมูลเสียง
    content_type = response.headers.get('Content-Type', '')

    if 'audio' in content_type:
        # Define the output filename for the audio file
        # กำหนดชื่อไฟล์สำหรับบันทึกเสียงที่ดาวน์โหลด
        output_filename = f"voice_preview_{VOICE_ID_TO_PREVIEW}.mp3"

        # Open the file in binary write mode and save the audio stream
        # เปิดไฟล์ในโหมดเขียนไบนารี (binary write mode) และบันทึกการสตรีมเสียงลงในไฟล์
        with open(output_filename, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192): # Iterate over the response content in chunks
                f.write(chunk) # Write each chunk to the file
        print(f"✅ ตัวอย่างเสียงถูกบันทึกที่: {os.path.abspath(output_filename)}")
    else:
        # If the content type is not audio, it means there might be an API error.
        # Try to parse the response as JSON to get the error message.
        # หาก Content-Type ไม่ใช่เสียง แสดงว่าอาจมีข้อผิดพลาดจาก API
        # พยายามแยกวิเคราะห์การตอบกลับเป็น JSON เพื่อรับข้อความแสดงข้อผิดพลาด
        try:
            error_data = response.json()
            print(f"⚠️ ข้อผิดพลาดจาก API: {error_data}")
        except requests.exceptions.JSONDecodeError:
            # If it's not JSON and not audio, print the raw content and content type.
            # หากไม่ใช่ทั้ง JSON และเสียง ให้พิมพ์เนื้อหาและ Content-Type ดิบๆ
            print(f"❌ ได้รับ Content-Type ที่ไม่คาดคิด: {content_type}")
            print(f"เนื้อหาที่ได้รับ (อาจเป็นข้อความแสดงข้อผิดพลาด): {response.text}")

except requests.exceptions.RequestException as e:
    # Catch any request-related exceptions (e.g., network issues, invalid URL, HTTP errors)
    # ดักจับข้อยกเว้นที่เกี่ยวข้องกับ request (เช่น ปัญหาเครือข่าย, URL ไม่ถูกต้อง, ข้อผิดพลาด HTTP)
    print(f"❌ เกิดข้อผิดพลาดในระหว่างการร้องขอ: {e}")