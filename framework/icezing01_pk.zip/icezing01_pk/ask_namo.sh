#!/bin/bash

LM_API_URL="http://192.168.137.1:1234/v1/chat/completions"
TTS_ENGINE="espeak" # หรือ "say" ถ้า MacOS, "espeak" ถ้า Linux

# อ่านคำถามจากพี่
read -p "❓ พี่ถาม NaMo: " user_input

# สร้าง JSON Payload
payload=$(cat <<EOF
{
  "model": "liquid/lfm2-1.2b",
  "messages": [
    { "role": "system", "content": "Always answer in rhymes. Today is Thursday" },
    { "role": "user", "content": "$user_input" }
  ],
  "temperature": 0.3,
  "max_tokens": 500,
  "stream": false
}
EOF
)

# ยิง API แล้วดึงเฉพาะ content
response=$(curl -s $LM_API_URL \
  -H "Content-Type: application/json" \
  -d "$payload" | sed -n 's/.*"content": "\(.*\)".*/\1/p')

# แสดงคำตอบ
echo -e "\n📝 NaMo ตอบ:\n$response\n"

# พูดด้วยเสียง
if command -v $TTS_ENGINE > /dev/null; then
  echo "🎤 กำลังพูด..."
  echo "$response" | $TTS_ENGINE
else
  echo "⚠️ ไม่พบ TTS Engine ติดตั้ง ใช้ได้แค่ข้อความ"
fi
