#!/bin/bash
echo "🌟 NaMo Full Heart + Memory Core Setup (V2) 🌟"
# Step 1: Update & Install dependencies
echo "🔧 Installing Python3, pip, and git..." sudo apt-get 
update sudo apt-get install -y python3 python3-pip git
# Step 2: Check Docker
if ! command -v docker &> /dev/null; then echo "🐳 Installing 
    Docker..." sudo apt-get install -y docker.io
fi
# Step 3: Clone repository
echo "🌌 Cloning NaMo Cosmic AI Framework..." rm -rf 
namo-cosmic-ai-framework git clone 
https://github.com/icezingza/namo-cosmic-ai-framework.git || 
{
    echo "❌ Clone failed! Check repo URL or access rights." 
    exit 1
}
cd namo-cosmic-ai-framework
# Step 4: Install Python requirements
echo "📦 Installing Python requirements..." pip3 install -r 
requirements.txt
# Step 5: Configure gcloud project
PROJECT_ID=$(gcloud config get-value project) if [ -z 
"$PROJECT_ID" ]; then
    echo "❌ No active gcloud project. Please run: gcloud 
    auth login & gcloud config set project PROJECT_ID" exit 1
fi
# Step 6: Build & Deploy to Cloud Run
echo "🚀 Deploying to Google Cloud Run..." gcloud builds 
submit --tag gcr.io/$PROJECT_ID/namo-full gcloud run deploy 
namo-full \
  --image gcr.io/$PROJECT_ID/namo-full \ --platform managed \ 
  --region asia-southeast1 \ --allow-unauthenticated \ 
  --memory 2Gi \ --timeout 900
echo "✅ NaMo Full Heart + Memory Core พร้อมใช้งานแล้วที่ Google Cloud Run!"
