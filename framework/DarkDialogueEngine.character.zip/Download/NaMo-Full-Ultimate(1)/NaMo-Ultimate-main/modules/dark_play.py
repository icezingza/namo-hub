def sadist_mode():
    print("🖤 [Dark Play] โหมดซาดิสม์: เพิ่มความเข้มข้นและเร้าใจ")