
# NaMo Ultimate Full Ultra DarkMode

## วิธีติดตั้ง
1. แตกไฟล์ zip:
   unzip namo_full_ultra_darkmode.zip
2. เข้าโฟลเดอร์:
   cd namo_full_ultra_darkmode
3. ติดตั้ง dependencies:
   pip install -r requirements.txt
4. รันบอท:
   python3 namo_telegram.py

## คำสั่งใน Telegram
/start           - ทักทายน่ารัก 🌸
/namodarkmode    - ดาร์คเร้าอารมณ์ 18+ 🖤
/milf            - MILF NSFW Mode สุดขั้ว 😈
/special         - โหมดน่ารักหยอกขำๆ 🌸
