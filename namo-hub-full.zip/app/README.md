Web app สำหรับ visualize blueprint/solution knowledge base
