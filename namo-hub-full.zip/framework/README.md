เก็บ framework เอกสาร เช่น Data hygiene + Knowledge architecture
