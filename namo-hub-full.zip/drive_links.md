# Drive Links Index
- Dataset: [Google Drive link]
- Slides: [Google Drive link]
- PDF raw docs: [Google Drive link]
